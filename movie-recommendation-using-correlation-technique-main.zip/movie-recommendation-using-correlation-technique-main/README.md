# movie recommendation using correlation technique
 mini project
